/**
 *  SPAN - Smart Phone Ad-Hoc Networking project
 *  Copyright (c) 2012 The MITRE Corporation.
 */
package org.span.service.legal;

public interface EulaObserver {

	// callback methods
	
	public void onEulaAccepted();
	
}